#!/usr/bin/env ruby

# @todo HIGH behat oneclick executor