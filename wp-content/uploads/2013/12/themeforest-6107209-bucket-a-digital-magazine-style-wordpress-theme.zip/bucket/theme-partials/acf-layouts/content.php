<?php

/**
 * Content Component
 * Fields available:
 * @content wysiwyg
 */

?><div class="content-module">
	<?php the_sub_field("content"); ?>
</div><?php
