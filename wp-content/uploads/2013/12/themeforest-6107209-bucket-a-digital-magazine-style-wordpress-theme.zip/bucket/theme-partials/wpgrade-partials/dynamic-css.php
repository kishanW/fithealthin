<?php

	/**
	 * Load google fonts appropriate script block.
	 *
	 * This callback is invoked by wpgrade_callback_enqueue_dynamic_css
	 */

