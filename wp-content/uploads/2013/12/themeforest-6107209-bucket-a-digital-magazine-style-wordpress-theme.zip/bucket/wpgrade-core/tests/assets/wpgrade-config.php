<?php return array
	(
		'name' => 'testgrade',
		'textdomain' => null,

		'theme-options' => array
			(
				'unittest_test_option' => 'success',
			),

	); # end test configuration
