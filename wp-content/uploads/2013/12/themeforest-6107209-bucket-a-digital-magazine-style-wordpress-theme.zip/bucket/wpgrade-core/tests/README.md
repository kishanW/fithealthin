This section contains unit tests for wpgrade-system.

These are not unit tests for the theme or wordpress functions, these tests
cover only the logic defined by wpgrade-system classes.
