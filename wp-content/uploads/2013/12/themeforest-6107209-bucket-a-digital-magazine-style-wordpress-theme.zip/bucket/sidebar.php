<?php if (!dynamic_sidebar('sidebar')): ?>
<?php endif; ?>