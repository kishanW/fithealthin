The Documentation is available online through our HelpDesk system located on http://help.pixelgrade.com

Knowledge Base: http://bit.ly/lens-documentation

Installation and Setup video: http://bit.ly/lens-setup

Open a new ticket: http://bit.ly/new-ticket

